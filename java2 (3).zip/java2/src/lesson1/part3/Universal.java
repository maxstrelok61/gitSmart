package lesson1.part3;

public interface Universal extends Pet, Waterfowl {
}
