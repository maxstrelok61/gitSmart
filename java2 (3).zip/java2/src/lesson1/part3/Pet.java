package lesson1.part3;

public interface Pet {

    /*public static final */String TITLE = "tewt";

    /*public abstract*/ void loveMaster();

}
