package lesson5.lambda;

public interface ConstVar {
    void start();
}
