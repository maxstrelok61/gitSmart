package lesson5.lambda;

public interface TwoVar {
    void start(int a, int b);

}
