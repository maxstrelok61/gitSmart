package lesson5.lambda;

public interface NoneVar {
    void start();
}
