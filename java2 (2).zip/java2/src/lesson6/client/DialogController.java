package lesson6.client;

import javafx.stage.Stage;

public class DialogController {

    private Stage dialogStage;

}
