package lesson2.homework;

public class MyArraySizeException extends Exception {


    public MyArraySizeException(String message) {
        super(message);
    }
}
