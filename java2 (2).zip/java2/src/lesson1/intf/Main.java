package lesson1.intf;

public class Main implements One, Two {


}
