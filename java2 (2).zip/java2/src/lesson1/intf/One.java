package lesson1.intf;

public interface One {
/*    default void action() {
        System.out.println("One");
    }*/
}
