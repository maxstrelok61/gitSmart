package lesson1.part1;

public class TestDocument {

    public static void main(String[] args) {

    }
}
